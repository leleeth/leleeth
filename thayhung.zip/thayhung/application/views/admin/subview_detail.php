<pre><?php
print_r($data);