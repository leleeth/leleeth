<?php 
class meo extends CI_Controller{
	public function index(){
		$this->load->model('MMeo');
		$data = $this->MMeo->all();
		
		$this -> load -> view ('meo/index',['dulieu'=>$data]);
	}
}
?>