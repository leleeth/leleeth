<?php
class MMeo extends CI_Model{
	function all(){
		$data = $this->db->get('sanpham');
		return $data -> result();
	}
} 
 ?>